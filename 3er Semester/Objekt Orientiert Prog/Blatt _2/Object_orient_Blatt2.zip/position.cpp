//
// Created by mahdi on 19.10.2024.
#include<iostream>
#include "position.h"

    void position::set(const std::string &name,int x , int y ){
        c_name = name;
        this-> x = x;
        this->y = y;
    }
    const std::string& position::getName() const
    {
        return c_name;
    }
    int position::getX()const
    {
        return x;
    }
    int position::getY() const
    {
        return y;
    }


