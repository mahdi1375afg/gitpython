#include <iostream>
#include <assert.h>
#include "position.h"
namespace nsPosition {
    void sort(int* numbers, int const size){
        for (int i = 1; i < size; ++i) {
            int key = numbers[i];
            int j = i - 1;
            while (j >= 0 && numbers[j] > key) {
                numbers[j + 1] = numbers[j];
                j = j - 1;
            }
            numbers[j + 1] = key;
        }
    }

    void test_sort(int* numbers, int const size) {
        sort(numbers, size);

        std::cout << "test started" << std::endl;
        for (int i = 0 ; i< size-1; i++)
        {
            assert(numbers[i] <= numbers[i + 1]);
        }
        std::cout << "test passed" << std::endl;
    }
    void test_sort() {
        int numbers1 [] = {3, 2, 1, 5, 4,9,99,70};
        int numbers2 [] = {19,1,12,3,20,10};
        int numbers3 [] = {36,87,93,50,22,63};
        int numbers4 [] = {5,4,3,2,1,0,12,11};
        test_sort(numbers1, 8);
        test_sort(numbers2, 6);
        test_sort(numbers3, 5);
        test_sort(numbers4, 8);

    }

    void test_compare();
}
    int main() {
        int number []= {3,2,1,3,4,1};
        nsPosition::test_sort(number, 6);
//nsPosition::test_sort();
  //      nsPosition::position::testPosition();
    //    nsPosition::test_compare();

        return 0;
    }
