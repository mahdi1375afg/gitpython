//
// Created by mahdi on 03.11.2024.
//

#include "City.h"
#include <iostream>
namespace MahdiHfu {
    City::City(const Position &position,const std::string *POI,const int size): position(position),POI(copyPOI(POI,size)) ,size(size) {
    }
    int City::getX()const{
        return position.getX();
    }
    int City::getY()const {
        return position.getY();
    }
    std::string City::getName()const {
        return position.getName();
    }
    std::string City::getPOI(const int i)const{
        if(i < 0 || i >= getNumberOfPOIs()) {
            throw std::out_of_range("Index out of range");
        }
        return this->POI[i];
        };
    bool City::setPOI(const int i, std::string poi)const {
        if(i < 0 || i >= getNumberOfPOIs()) {
            throw std::out_of_range("Index out of range");
        }
        this->POI[i] = poi;
        return true;

    }
    int City::getNumberOfPOIs()const{

        return size;
    }
    }

 // MahdiHfu