//
// Created by mahdi on 03.11.2024.
//

#ifndef CITY_H
#define CITY_H
#include <string>
#include "Position.h"
namespace MahdiHfu {

class City {
private:
    std::string *POI;
    Position position;
    int size;
    static std::string *copyPOI(const std::string *copyPOI, const int size) {
        const auto result = new std::string[size];
        for (int i = 0; i < size; ++i) {
            result[i] = copyPOI[i];
        }
        return result;
    }


public:
    City(const Position &position,const std::string *POI,int size);
    std::string getName()const;
    int getX()const;
    int getY()const;
    std::string getPOI(int i)const;
    bool setPOI(int i, std::string poi)const;
    int getNumberOfPOIs()const;

};

} // MahdiHfu

#endif //CITY_H
