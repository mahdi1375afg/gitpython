#include <cassert>
#include <string>
#include "City.h"
#include "Position.h"
#include <iostream>

namespace MahdiHfu{
MahdiHfu::Position createPosition() {
    std::cout << "position test started" << std::endl;
    std::string mordor = "Mordor";
    MahdiHfu::Position result(mordor, 47, 11);
    std::cout << "position test passed" << std::endl;
    return result;
}

MahdiHfu::City createCity(){
    std::cout<<"city test started"<<std::endl;
    auto position=createPosition();
    std::string pois[]={"Sauron", "Minas Morgul", "Orodruin"};
    MahdiHfu::City result(position, pois, 3);
    std::cout<<"city test passed"<<std::endl;
    return result;
}

void testCtor(){
    std::cout<<"Ctor test started"<<std::endl;
    auto position=createPosition();
    std::string pois[]={"Sauron", "Minas Morgul", "Orodruin"};
    MahdiHfu::City city(position,pois,3);
    pois[0]="Gandalf";
    assert(city.getPOI(0)=="Sauron");
    std::cout<<"Ctor test passed"<<std::endl;
}

void testGetNameXY(){
    std::cout<<"GetNameXY test started"<<std::endl;
    auto position=createPosition();
    MahdiHfu::City city(position, nullptr,0);
    assert(city.getName()=="Mordor");
    assert(city.getX()==47);
    assert(city.getY()==11);
    std::cout<<"GetNameXY test passed"<<std::endl;
}


void testGetPOI(){
    std::cout<< "GetPOI test started" << std::endl;
    auto city=createCity();
    assert(city.getPOI(0)=="Sauron");
    assert(city.getPOI(1)=="Minas Morgul");
    assert(city.getPOI(2)=="Orodruin");
    try {
        city.getPOI(3);
        assert(false);
    }catch (...){}
    try {
        city.getPOI(-1);
        assert(false);
    }catch (...){}
    std::cout<< "GetPOI test passed" << std::endl;
}

void testSetPOI(){
    std::cout<< "SetPOI test started" << std::endl;
    auto city=createCity();
    city.setPOI(0,"Gandalf");
    assert(city.getPOI(0)=="Gandalf");

    try {
        city.setPOI(3,"Gandalf");
        assert(false);
    }catch (...){}
    try {
        city.setPOI(-1,"Gandalf");
        assert(false);
    }catch (...){}
    std::cout<< "SetPOI test passed" << std::endl;
}

void testGetNumberOfPOIs(){
    std::cout<< "GetNumberOfPOIs test started" << std::endl;
    auto city=createCity();
    assert(city.getNumberOfPOIs()==3);
    std::cout<< "GetNumberOfPOIs test passed" << std::endl;
}


void testCity() {
    testCtor();
    testGetNameXY();
    testGetPOI();
    testSetPOI();
    testGetNumberOfPOIs();
}
}
int main (){
    std::cout<< "All test started" << std::endl;
    MahdiHfu::testCity();
    std::cout<< "All test passed" << std::endl;
}//
